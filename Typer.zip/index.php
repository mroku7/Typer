<?php
include_once("header.php");
include_once("slider.php");
include_once("navBar.php");
include_once("mainContent.php");
include_once("footer.php");