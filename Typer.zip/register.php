<?php
    session_start();
    include('header.php');
    include('navBar.php');
    if(isset($_POST['nick'])){
        $allOk = true;
        // Checking Nickname/////////////////////////////////////////////////////////////////
        $nick = $_POST['nick'];
        if((strlen($nick)<3) || (strlen($nick)>20)){
            $allOk = false;
            $_SESSION['e_nick']="Nick musi posiadać od 3 do 20 znaków";
        }
        if(!(ctype_alnum($nick))){
            $allOk = false;
            $_SESSION['e_nick']="Nick może zawierać tylko litery i cyfry.";
        }

        //Checking email/////////////////////////////////////////////////////////////////////
        $email = $_POST['email'];
        $emailB = filter_var($email, FILTER_SANITIZE_EMAIL);

        if((filter_var($emailB, FILTER_VALIDATE_EMAIL)==false) || ($email!=$emailB)){
            $allOk = false;
            $_SESSION['e_email']="Podaj poprawny adres email";
        }

        //Checking password///////////////////////////////////////////////////////////////////
        $password = $_POST['password'];
        $password1 = $_POST['password1'];

        if((strlen($password))<8 || (strlen($password)>20)){
            $allOk = false;
            $_SESSION['e_haslo']="Hasło musi posiadać od 8 do 20 znaków";
        }
        if($password!=$password1){
            $allOk = false;
            $_SESSION['e_haslo']="Podane hasła różnią się";
        }

        //Password hash///////////////////////////////////////////////////////////////////////
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        //Checkbox check//////////////////////////////////////////////////////////////////////
        if(!(isset($_POST['agreement']))){
            $allOk = false;
            $_SESSION['e_agreement']="Potwierdź akceptacje regulaminu.";
        }

        //reCAPTCHA//////////////////////////////////////////////////////////////////////////////
        $secret = "6Lf3o0UUAAAAAEViVXCxlTiRihgwSYgxISKCJuMZ";

        $check = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);

        $answer = json_decode($check);

        if(!($answer->success)){
            $allOk = false;
            $_SESSION['e_bot']="Jesteś botem?";
        }


        require_once "includes/connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);

		try
		{
			$connect = new mysqli($host, $db_user, $db_password, $db_name);
			if ($connect->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
            }
            else{
                //email in db?//////////////////////////////////////////////////////////////////
                $res = $connect->query("SELECT id FROM users WHERE email='$email'");

                if(!$res) throw new Exception($connect->error);

                $howManyEmails = $res->num_rows;
                if($howManyEmails>0){
                    $allOk = false;
                    $_SESSION['e_email']="Istneje już konto przypisane do tego emaila.";
                }

                //name in db?//////////////////////////////////////////////////////////////////////
                $res = $connect->query("SELECT id FROM users WHERE user='$nick'");

                if(!$res) throw new Exception($connect->error);

                $howManyUsers = $res->num_rows;
                if($howManyUsers>0){
                    $allOk = false;
                    $_SESSION['e_nick']="Wybrany nick jest zajęty";
                }

                if($allOk){
                    if($connect->query("INSERT INTO users VALUES(NULL, '$nick', '$password_hash', '$email')")){

                        $_SESSION['registerDone'] = true;
                        header('Location: hello.php');
                    }else{

                        throw new Exception($connect->error);
                    }
                    $_SESSION['nick'] = $nick;
                    $_SESSION['$password_hash'] = $password_hash;
                    $_SESSION['$email'] = $email;
                    $_SESSION['codeSend']=true;
                    include('emailVer.php');
                    header('Location: code.php');


                }

                $connect->close();
            }

        }
        catch(Exception $e)
		{
			echo '<span class="error">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</span>';
			//echo '<br />Dev info: '.$e;
		}
   }

?>
<div>
<form method="post">
    Nickname: <br/> <input type="text" name="nick"/><br/>
    <?php
        if(isset($_SESSION['e_nick'])) {
            echo '<div class="error">'.$_SESSION['e_nick'].'</div>';
            unset($_SESSION['e_nick']);
        }
    ?>

    Email: <br/> <input type="text" name="email"/><br/>
    <?php
        if(isset($_SESSION['e_email'])) {
            echo '<div class="error">'.$_SESSION['e_email'].'</div>';
            unset($_SESSION['e_email']);
        }
    ?>

    Hasło: <br/> <input type="password" name="password"/><br/>
    <?php
        if(isset($_SESSION['e_haslo'])) {
            echo '<div class="error">'.$_SESSION['e_haslo'].'</div>';
            unset($_SESSION['e_haslo']);
        }
    ?>
    Powtórz hasło: <br/> <input type="password" name="password1"/><br/>

    <label><input type="checkbox" name="agreement" /> Akceptuje regulamin </label>
    <?php
        if(isset($_SESSION['e_agreement'])) {
            echo '<div class="error">'.$_SESSION['e_agreement'].'</div>';
            unset($_SESSION['e_agreement']);
        }
    ?>
    <div class="g-recaptcha" data-sitekey="6Lf3o0UUAAAAAKNPhJgJsFQR4UY2DLrGg-N5pXM3"></div>
    <?php
        if(isset($_SESSION['e_bot'])) {
            echo '<div class="error">'.$_SESSION['e_bot'].'</div>';
            unset($_SESSION['e_bot']);
        }
    ?>
    <br>
    <input id="registerSubmit" type="submit" value="Zarejestruj" />


</form>
</div>
<?php
    include('footer.php');
//?>