<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="styles.css?v=<?php time(); ?>">
    <meta charset="utf8"/>
    <script defer src="img\svg-with-js\js\fontawesome-all.js"></script>
    <script src="libs\jquery-3.3.1.min.js"></script>
    <script src="js\slideTab.js"></script>


</head>
<body>
<div id="biggestDiv">
    <div id="mainDiv">
        <div>
            <div id="banner">
                <a href="index.php" title="Return to Home">
                    <img src="img/banner.png">
                </a>
            </div>
        </div>

