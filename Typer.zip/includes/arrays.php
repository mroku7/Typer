<?php

$navItems = array(
    array(
        "link" => "index.php",
        "title" => "Strona Główna"
    ),
    array(
        "link" => "contact.php",
        "title" => "Kontakt"
    )
);


