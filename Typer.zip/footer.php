<div id="footer" class="fa-2x" style="color: white">
    <i class="fab fa-facebook-square"></i><br>
    <i class="fas fa-envelope-open"></i>
</div>
</div> <!-- mainDiv close -->
</div> <!-- biggestDiv close -->