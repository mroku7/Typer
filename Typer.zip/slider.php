<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <form id="login">
        <div class="sliderForm">
            <label for="nick">Nick</label>
            <input type="text" id="nick"><br>
        </div>
        <div class="sliderForm">
            <label for="password">Hasło</label>
            <input type="password">
        </div>
        <div id="sliderButtons">
        <a href="register.php" id="register">Rejestracja</a>
        <input id="loginSubmit" type="submit" value="Zaloguj">
        </div>
    </form>
</div>